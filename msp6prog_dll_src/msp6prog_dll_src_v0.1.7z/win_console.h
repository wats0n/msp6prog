#ifndef WIN_CONSOLE_H
#define WIN_CONSOLE_H

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport )  void* con_init(void);
__declspec( dllexport )  void con_cls(void* hConsole);

#ifdef __cplusplus
}
#endif

#endif
