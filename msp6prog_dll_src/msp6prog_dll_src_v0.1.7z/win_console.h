//----------------------------------------------------------------------------
// Name:        win_console.h
// Purpose:     Header for win_console.cpp with extern "C" for DLL build
//
// Author:      Watson Huang <wats0n.edx@gmail.com>
//
// Created:     01/19, 2015
// Copyright:   (c) 2015 by Watson Huang
// License:     MIT License
//----------------------------------------------------------------------------

#ifndef WIN_CONSOLE_H
#define WIN_CONSOLE_H

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport )  void* con_init(void);
__declspec( dllexport )  void con_cls(void* hConsole);

#ifdef __cplusplus
}
#endif

#endif
