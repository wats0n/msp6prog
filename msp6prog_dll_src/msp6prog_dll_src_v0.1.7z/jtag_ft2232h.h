#ifndef JTAG_FT2232_H
#define JTAG_FT2232_H

//Data control command
typedef struct dctrlcmd_s
{
	unsigned char bycmd;
	unsigned char bicmd;
} dctrlcmd_t;

typedef struct jtagpara_s
{
	void* handle;
	unsigned int freq;			//device frequence
	unsigned int devidx;		//device index
	unsigned char cmd_tms;		//assign TMS value to push JTAG FSM
	dctrlcmd_t ir;
	dctrlcmd_t drlo;
	dctrlcmd_t drli;
	dctrlcmd_t drmo;
	dctrlcmd_t drmi;
} jtagpara_t;

typedef struct ircmd_s
{
	unsigned int cmd;
	unsigned int tckdly; //assign TCK delay after send command
	char* name;
} ircmd_t;

typedef struct fpgajcmd_s
{
	unsigned int ir_len;		//FPGA IR(Instruction Register) Length, by bits
	unsigned int dr_stride;		//FPGA DR Output size, 1~0xFFFF.
	ircmd_t *cmdlist;
} fpgajcmd_t;

typedef struct fpgapara_s
{
	char* name;
	unsigned int idcode;
	unsigned int maxbits;
	fpgajcmd_t *jcmd;
} fpgapara_t;

#ifdef __cplusplus
extern "C" {
#endif

//Jtag Functions
//Form Xilinx ug380.pdf Figure 10-2: Boundary-Scan TAP Controller
//TLR = Test-Logic-Reset, RTI = Run-Test/Idle
//Abbreviation from Table 10-4: Single Device Configuration Sequence
//Other single operation only available below RTI state, not go back to TLR
unsigned long jf_force2tlr(jtagpara_t* jtagpara);
unsigned long jf_tlr2rti(jtagpara_t* jtagpara);
unsigned long jf_rti2tlr(jtagpara_t* jtagpara); //compact operation for detect state error
//Send operation to Xilinx FPGA via JTAG, should start and end in RTI state.
unsigned long jf_ircmd(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned int ircmd);
unsigned long jf_drout(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned char* dbuf, unsigned int dbuflen);
unsigned long jf_drin(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned char* dbuf, unsigned int dbuflen, unsigned int *drdlen);

unsigned long jdev_open(jtagpara_t* jtagpara);
unsigned long jdev_close(jtagpara_t* jtagpara);

//Using "Blind Interrogation" Trick to detect fpga
//http://www.fpgarelated.com/comp.arch.fpga/thread/77524/jtag-ir-length-detection.php
//Could add device count algorithm to check all device, but this program only detect first device. 
__declspec( dllexport ) unsigned long jtag_blankinterrogation(jtagpara_t* jtagpara, fpgapara_t* support_list, fpgapara_t* detect_fpga);
//unsigned long jtag_testbypass(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned char* buf, unsigned int buflen);

__declspec( dllexport ) unsigned long jtag_cfgfpga(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, char* fpgafile);

//int jtag_idflash(void);
//int jtag_cfgflash(char* fpagfile, char* flashfile);

#ifdef __cplusplus
}
#endif

#endif