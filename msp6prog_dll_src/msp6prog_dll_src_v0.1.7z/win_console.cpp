//----------------------------------------------------------------------------
// Name:        win_console.cpp
// Purpose:     Allocate new console for DLL stdout printf procedure.
//
// Author:      Watson Huang <wats0n.edx@gmail.com>
//
// Created:     01/19, 2015
// Copyright:   (c) 2015 by Watson Huang
// License:     MIT License
//----------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>

#include "win_console.h"

void* con_init(void)
{
	HANDLE hStdout;
	if(fileno(stdout)<0)
	{
		//If not exist console, create one.
		AllocConsole();
		SetConsoleTitle("Debug");
		freopen("CONOUT$", "w", stdout);
	}
	//return (fileno(stdout)); //Test

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	return hStdout;
}

//Clear Console: http://support.microsoft.com/kb/99261

void con_cls(void* hConsole)
{
	COORD coordScreen = { 0, 0 };    /* here's where we'll home the
                                        cursor */ 
    BOOL bSuccess;
    DWORD cCharsWritten;
    CONSOLE_SCREEN_BUFFER_INFO csbi; /* to get buffer info */ 
    DWORD dwConSize; 
	
	/* get the number of character cells in the current buffer */

	bSuccess = GetConsoleScreenBufferInfo( hConsole, &csbi );
    dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

    /* fill the entire screen with blanks */ 

    bSuccess = FillConsoleOutputCharacter( hConsole, (TCHAR) ' ',
       dwConSize, coordScreen, &cCharsWritten );

    /* get the current text attribute */ 

    bSuccess = GetConsoleScreenBufferInfo( hConsole, &csbi );

    /* now set the buffer's attributes accordingly */ 

    bSuccess = FillConsoleOutputAttribute( hConsole, csbi.wAttributes,
       dwConSize, coordScreen, &cCharsWritten );

    /* put the cursor at (0, 0) */ 

    bSuccess = SetConsoleCursorPosition( hConsole, coordScreen );

    return;
}