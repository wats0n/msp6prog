#include <Windows.h>
#include <stdio.h>

#include "ftd2xx.h"
#include "jtag_ft2232h.h"

//#include "ftd2xx.h" declare in jtag_ft2232.h
#pragma comment(lib, "ftd2xx.lib")

unsigned long jf_force2tlr(jtagpara_t* jtagpara)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	//DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	//DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE
	//Ready Test-Logic-Reset state
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x04;
	// Number of clock pulses = Length + 1 (4+1 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x1F;
	// Data is shifted LSB first, so the TMS pattern is 11111
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	return ftStatus;
}

unsigned long  jf_tlr2rti(jtagpara_t* jtagpara)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	//DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	//DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE
	//Goto Run-Test/Idle from Test-Logic-Reset
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x00;
	// Number of clock pulses = Length + 1 (0+1 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x00;
	// Data is shifted LSB first, so the TMS pattern is 0
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	return ftStatus;
}

unsigned long  jf_rti2tlr(jtagpara_t* jtagpara)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	//DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	//DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE
	//Goto Test-Logic-Reset state
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x02;
	// Number of clock pulses = Length + 1 (2+1 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x0F;
	// Data is shifted LSB first, so the TMS pattern is 111
	// Bit 3 set one means TMS keep 1 after last TCK end.
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	return ftStatus;
}

//Send operation to Xilinx FPGA via JTAG, should start and end in RTI state.
unsigned long  jf_ircmd(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned int ircmd)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	//DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	//DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read
	
	ircmd_t *selcmd=NULL;

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE

	for(selcmd = (cur_fpga->jcmd->cmdlist); selcmd->cmd != 0; selcmd++)
	{
		if(selcmd->cmd == ircmd)
			break;
	}

	printf("[Info] Send IR: %02X, %s\n", selcmd->cmd, selcmd->name);

	//Goto Shift-IR from Run-Test/Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x03;
	// Number of clock pulses = Length + 1 (4 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x03;
	// Data is shifted LSB first, so the TMS pattern is 1100
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	//Send IR CMD
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->ir.bicmd;
	byOutputBuffer[dwNumBytesToSend++] = (cur_fpga->jcmd->ir_len-1-1); //send irlen-1 bit
	// Number of clock pulses = Length + 1 (5 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = selcmd->cmd;
	// Data is shifted LSB first, so the TDI pattern is 10010
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	//Send last bit and goto Exit1-IR
	dwNumBytesToSend = 0; // Reset output buffer pointer
	// Here is the TMS command for one clock. Data is also shifted in.
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	// Clock out TMS, Read one bit.
	byOutputBuffer[dwNumBytesToSend++] = 0x00;
	// Number of clock pulses = Length + 0 (1 clock here)
	byOutputBuffer[dwNumBytesToSend++] = (((selcmd->cmd>>(cur_fpga->jcmd->ir_len-1))&0x01)?(0x80):(0x00))|(0x03);
	// Data is shifted LSB first, so TMS becomes 1. Also, bit 7 is shifted into TDI/DO, also a 1
	// The 1 in bit 1 will leave TMS high for the next commands.
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	//Goto Run-Test/Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	// Here is the TMS command for one clock. Data is also shifted in.
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	// Clock out TMS, Read one bit.
	byOutputBuffer[dwNumBytesToSend++] = 0x00;
	// Number of clock pulses = Length + 0 (1 clock here)
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Data is shifted LSB first, so TMS becomes 10
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	if(selcmd->tckdly)
	{
		unsigned int dlycnt;
		unsigned int dstride;

		dlycnt = selcmd->tckdly;
		dstride = 4; //push 4 TCK at once

		while(dlycnt >= dstride)
		{
			dwNumBytesToSend = 0; // Reset output buffer pointer
			byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
			byOutputBuffer[dwNumBytesToSend++] = (dstride-1);
			byOutputBuffer[dwNumBytesToSend++] = 0x00;
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			dlycnt -= dstride;
		}

		if(dlycnt)
		{
			dwNumBytesToSend = 0; // Reset output buffer pointer
			byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
			byOutputBuffer[dwNumBytesToSend++] = (dlycnt-1);
			byOutputBuffer[dwNumBytesToSend++] = 0x00;
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			dlycnt -= dstride;
		}

	}

	return ftStatus;
}

unsigned long  jf_drout(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned char* dbuf, unsigned int dbuflen)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE
	
	//Goto Shift-DR from Run-Test/Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x02;
	// Number of clock pulses = Length + 1 (3 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Data is shifted LSB first, so the TMS pattern is 100
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	printf("[Info] Write DR:\n");

	if(dbuflen)
	{
		unsigned char* sendbuf = NULL;
		unsigned int dstride = 0xFFFE;
		unsigned int dleft = dbuflen-1;
		unsigned int dproc = 0;
		unsigned int dcnt = 0;
		unsigned long bcnt, bmax;
		double bpercent;
		DWORD tbeg, tend;
		double tsec;
		
		if(cur_fpga->jcmd->dr_stride > 0xFFFF)
		{
			printf("[Error] One DR Stride is %d(0x%04X) too large. Reset to %d (0x%04X).\n", cur_fpga->jcmd->dr_stride, cur_fpga->jcmd->dr_stride, 0xFFFF, 0xFFFF);
			cur_fpga->jcmd->dr_stride = 0xFFFF;
		}
		else if(cur_fpga->jcmd->dr_stride == 0)
		{
			printf("[Error] One DR Stride is 0 too small. Reset to 1.\n");
			cur_fpga->jcmd->dr_stride = 1;
		}
		
		printf("[Info] One DR Stride legnth is %d (%04X) bytes.\n", cur_fpga->jcmd->dr_stride, cur_fpga->jcmd->dr_stride);
		dstride = cur_fpga->jcmd->dr_stride;

		bmax = dbuflen*8; //All Bitstream Legnth
		bcnt = 0;
		bpercent = (100.0*bcnt)/bmax;
		printf("\r[Info] Progress: %.02f%% [%d/%d (bits)]", bpercent, bcnt, bmax);

		sendbuf = (unsigned char*)malloc(dstride+3); //3 is cmd (1byte) + payload length (2byte)

		tbeg = GetTickCount();
		while (dleft != 0)
		{
			if(dleft > dstride)
			{
				dproc = dstride;
				dleft -= dstride;
			}
			else
			{
				dproc = dleft;
				dleft = 0;
			}
			//Send (buflen-1)byte (MSB)
			dwNumBytesToSend = 0; // Reset output buffer pointer
			sendbuf[dwNumBytesToSend++] = jtagpara->drmo.bycmd;
			sendbuf[dwNumBytesToSend++] = (dproc-1)&0xFF;
			sendbuf[dwNumBytesToSend++] = ((dproc-1)>>8)&0xFF;
			memcpy(sendbuf+3, dbuf+dcnt*dstride, (dproc));
			dwNumBytesToSend += (dproc);
			// Data is shifted LSB first, so the TMS pattern is 1, bit 1 remain TMS is 1 after TCK.
			ftStatus = FT_Write(ftHandle, sendbuf, dwNumBytesToSend, &dwNumBytesSent);

			dcnt += 1;
			
			Sleep(50);
			
			bcnt += dproc*8;
			bpercent = (100.0*bcnt)/bmax;
			printf("\r[Info] Progress: %.02f%% [%d/%d (bits)]", bpercent, bcnt, bmax);
		}
		
		free(sendbuf);
		sendbuf = NULL;

		//Send last byte upper 7 bits
		//Goto EXIT1-DR and last bit
		dwNumBytesToSend = 0; // Reset output buffer pointer
		byOutputBuffer[dwNumBytesToSend++] = jtagpara->drmo.bicmd;
		byOutputBuffer[dwNumBytesToSend++] = 0x06;
		// Number of clock pulses = Length + 1 (7 clocks here)
		byOutputBuffer[dwNumBytesToSend++] = (*(dbuf + (dbuflen-1)));
		// Data is shifted LSB first, so the TMS pattern is 1, bit 1 remain TMS is 1 after TCK.
		ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

		bcnt += 7;
		bpercent = (100.0*bcnt)/bmax;
		printf("\r[Info] Progress: %.02f%% [%d/%d (bits)]", bpercent, bcnt, bmax);
		
		//Goto EXIT1-DR with last bit
		dwNumBytesToSend = 0; // Reset output buffer pointer
		byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
		byOutputBuffer[dwNumBytesToSend++] = 0x00;
		// Number of clock pulses = Length + 1 (1 clocks here)
		byOutputBuffer[dwNumBytesToSend++] = (((*(dbuf + (dbuflen-1)))&0x01)?(0x80):(0x00))|(0x03);
		// Data is shifted LSB first, so the TMS pattern is 1, bit 1 remain TMS is 1 after TCK.
		ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

		bcnt += 1;
		bpercent = (100.0*bcnt)/bmax;
		printf("\r[Info] Progress: %.02f%% [%d/%d (bits)]", bpercent, bcnt, bmax);
		printf("\n");

		tend = GetTickCount();
		tsec = (tend-tbeg);
		printf("[Info] Elaspe Time: %.03f (sec)\n", tsec/1000);
		printf("[Info] Write Speed: %.03f (bytes/sec)\n", ((double)dbuflen)/(tsec/1000));

	}

	//Go through Update-DR to Run-Test-Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Number of clock pulses = Length + 1 (2 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Data is shifted LSB first, so the TMS pattern is 10
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	return 0;
}

unsigned long  jf_drin(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, unsigned char* dbuf, unsigned int dbuflen, unsigned int *drdlen)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	//BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftHandle = jtagpara->handle;
	if(!ftHandle)
		return 1; //FT_INVALID_HANDLE
	
	//Goto Shift-DR from Run-Test/Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x02;
	// Number of clock pulses = Length + 1 (3 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Data is shifted LSB first, so the TMS pattern is 100
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	//Read DR by LBS
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->drli.bycmd;
	byOutputBuffer[dwNumBytesToSend++] = (dbuflen-1)&0xFF; //(dbuflen-1)byte, lo-byte
	byOutputBuffer[dwNumBytesToSend++] = ((dbuflen-1)>>8)&0xFF; //(dbuflen-1)byte, hi-byte
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	//Goto EXIT1-DR
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x00;
	// Number of clock pulses = Length + 1 (1 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x03;
	// Data is shifted LSB first, so the TMS pattern is 1, bit 1 remain TMS is 1 after TCK.
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

	//Go through Update-DR to Run-Test-Idle
	dwNumBytesToSend = 0; // Reset output buffer pointer
	byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Number of clock pulses = Length + 1 (2 clocks here)
	byOutputBuffer[dwNumBytesToSend++] = 0x01;
	// Data is shifted LSB first, so the TMS pattern is 10
	ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
	
	Sleep(50);
	ftStatus = FT_GetQueueStatus(ftHandle, &dwNumBytesToRead);

	if(dwNumBytesToRead > dbuflen)
	{
		printf("[Error] Exceed Read Buffer, fit to Read Buffer.\n");
		dwNumBytesToRead = dbuflen;
	}
	ftStatus = FT_Read(ftHandle, dbuf, dwNumBytesToRead, &dwNumBytesRead);
	*drdlen = dwNumBytesRead;
	if(ftStatus == FT_OK)
		ftStatus = FT_Purge(ftHandle, FT_PURGE_RX);
	
	{
		unsigned int i;
		printf("[Info] Read DR: ");
		for(i=0; i<dwNumBytesRead; i++)
			printf("%02X", *(dbuf+(dwNumBytesRead-1)-i));
		printf("\n");
	}

	return ftStatus;
}

unsigned long  jdev_open(jtagpara_t* jtagpara)
{
	FT_HANDLE ftHandle = 0;
	FT_STATUS ftStatus = 0; 
	DWORD dwNumDevs = 0;

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read
	DWORD dwClockDivisor = 0; // Value of clock divisor. if set 2, Frequency = 60/((1+2)*2) (MHz) = 10.0Mhz, Work

	DWORD dwDriverVer;
	DWORD dwLibraryVer;

	FT_DEVICE ftDevice;
	DWORD deviceID;
	char SerialNumber[16];
	char Description[64]; 
	
	printf("[Info] Open JTAG Device.\n");

	ftStatus = FT_GetLibraryVersion(&dwLibraryVer);
	if(ftStatus == FT_OK)
	{
		printf("[Info] Library Version: %02X.%02X.%02X\n", (dwLibraryVer>>(16))&0xFF, (dwLibraryVer>>(18))&0xFF, (dwLibraryVer>>(0))&0xFF);
	}
	else
	{
		printf("[Error] Unknown Library Version.\n");
		return 0xFF;
	}

	ftStatus = FT_CreateDeviceInfoList(&dwNumDevs);

	printf("[Info] Get %d Device(s).\n", dwNumDevs);

	if(dwNumDevs == 0)
	{
		printf("[Error] No Device Detected.\n");
	}
	
	if (ftStatus == FT_OK && dwNumDevs > 0) // Exit if we don't see any
	{
		ftStatus = FT_Open(jtagpara->devidx, &ftHandle); //always open 0 for msp6 jtag port
		printf("[Info] Assign Open Device[%d].\n", jtagpara->devidx);
		
		if(ftStatus != FT_OK)
		{
			printf("[Error] Can't Open Device[%d].\n", jtagpara->devidx);
			return 0xFF;
		}

		ftStatus = FT_GetDriverVersion(ftHandle, &dwDriverVer);
		if(ftStatus == FT_OK)
		{
			printf("[Info] Driver Version: %02X.%02X.%02X\n", (dwDriverVer>>(16))&0xFF, (dwDriverVer>>(18))&0xFF, (dwDriverVer>>(0))&0xFF);
		}
		else
		{
			printf("[Error] Unknown Driver Version.\n");
			ftStatus = FT_Close(ftHandle);
			return 0xFF;
		}
		
		SerialNumber[16-1] = '\0';
		Description[64-1] = '\0';

		ftStatus = FT_GetDeviceInfo(
			ftHandle,
			&ftDevice,
			&deviceID,
			SerialNumber,
			Description,
			NULL
			);
		
		if (ftStatus == FT_OK)
		{
			if(ftDevice == FT_DEVICE_2232H)
			{
				printf("[Info] FT2232H Device ID: %08X, SN:%s\n", deviceID, SerialNumber);
				printf("[Info] Desc.: %s\n", Description);

			}
			else
			{
				 printf("[Error] Unsupported Device: %X\n", ftDevice);
				 ftStatus = FT_Close(ftHandle);
				 return 0xFF;
			}
		}

		if(ftStatus == FT_OK)
		{
			//Use FTDI code sample setting
			ftStatus |= FT_ResetDevice(ftHandle);
			//Reset USB device
			//Purge USB receive buffer first by reading out all old data from FT2232H receive buffer
			ftStatus |= FT_GetQueueStatus(ftHandle, &dwNumBytesToRead);
			// Get the number of bytes in the FT2232H receive buffer
			if ((ftStatus == FT_OK) && (dwNumBytesToRead > 0))
				FT_Read(ftHandle, &byInputBuffer, dwNumBytesToRead, &dwNumBytesRead); //Clear FIFO?
			//Read out the data from FT2232H receive buffer
			ftStatus |= FT_SetUSBParameters(ftHandle, 65536, 65535);
			//Set USB request transfer sizes to 64K
			ftStatus |= FT_SetChars(ftHandle, false, 0, false, 0);
			//Disable event and error characters
			ftStatus |= FT_SetTimeouts(ftHandle, 0, 5000);
			//Sets the read and write timeouts in milliseconds
			ftStatus |= FT_SetLatencyTimer(ftHandle, 16);
			//Set the latency timer (default is 16mS)
			ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x00);
			//Reset controller
			ftStatus |= FT_SetBitMode(ftHandle, 0x0, 0x02);
			//Enable MPSSE mode
			Sleep(50); // Wait for all the USB stuff to complete and work
			
			dwNumBytesToSend = 0; // Start with a fresh index
			// Set up the Hi-Speed specific commands for the FTx232H
			byOutputBuffer[dwNumBytesToSend++] = 0x8A; //Use 60/1 MHz
			//byOutputBuffer[dwNumBytesToSend++] = 0x8B; //Use 60/5 MHz
			byOutputBuffer[dwNumBytesToSend++] = 0x97;
			// Turn off adaptive clocking (may be needed for ARM)
			byOutputBuffer[dwNumBytesToSend++] = 0x8D;
			// Disable three-phase clocking
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			// Send off the HS-specific commands
			
			if(!jtagpara->freq)
				jtagpara->freq += 1;
			dwClockDivisor = ((60*1000000)/(2*jtagpara->freq)-1); //F=60M/((1+D)*2), solve D
			
			if(dwClockDivisor>0xFFFF)
				dwClockDivisor = 0xFFFF;

			dwNumBytesToSend = 0; // Reset output buffer pointer
			// Set TCK frequency
			// TCK = 60MHz /((1 + [(1 +0xValueH*256) OR 0xValueL])*2)
			byOutputBuffer[dwNumBytesToSend++] = 0x86;
			// Command to set clock divisor
			byOutputBuffer[dwNumBytesToSend++] = dwClockDivisor & 0xFF;
			// Set 0xValueL of clock divisor
			byOutputBuffer[dwNumBytesToSend++] = (dwClockDivisor >> 8) & 0xFF;
			// Set 0xValueH of clock divisor
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

			printf("[Info] Set Device[%d] Frequency: %d\n", jtagpara->devidx, jtagpara->freq);

			dwNumBytesToSend = 0; // Reset output buffer pointer
			// Set initial states of the MPSSE interface
			// - low byte, both pin directions and output values
			// Pin name Signal Direction Config Initial State Config
			// ADBUS0 TCK/SK output 1 high 0
			// ADBUS1 TDI/DO output 1 low 0
			// ADBUS2 TDO/DI input	0 0
			// ADBUS3 TMS/CS output 1 high 0
			// ADBUS4 GPIOL0 output 1 low 0
			// ADBUS5 GPIOL1 output 1 low 0
			// ADBUS6 GPIOL2 output 1 low 0
			// ADBUS7 GPIOL3 output 1 low 0
			byOutputBuffer[dwNumBytesToSend++] = 0x80;
			// Configure data bits low-byte of MPSSE port
			byOutputBuffer[dwNumBytesToSend++] = 0x00;
			// Initial state config above
			byOutputBuffer[dwNumBytesToSend++] = 0xFB;
			// Direction config above
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			// Send off the low GPIO config commands
			
			dwNumBytesToSend = 0; // Reset output buffer pointer
			// Disable internal loop-back
			byOutputBuffer[dwNumBytesToSend++] = 0x85;
			// Disable loopback
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			// Send off the loopback command
			
			//Clear State to Test-Logic-State
			dwNumBytesToSend = 0; // Reset output buffer pointer
			byOutputBuffer[dwNumBytesToSend++] = 0x4B;
			byOutputBuffer[dwNumBytesToSend++] = 0x04;
			// Number of clock pulses = Length + 1 (5 clocks here)
			byOutputBuffer[dwNumBytesToSend++] = 0x1F;
			// Data is shifted LSB first, so the TMS pattern is 11111
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

			dwNumBytesToSend = 0; // Reset output buffer pointer
			// Set initial states of the MPSSE interface
			// - low byte, both pin directions and output values
			// Pin name Signal Direction Config Initial State Config
			// ADBUS0 TCK/SK output 1 high 0
			// ADBUS1 TDI/DO output 1 low 0
			// ADBUS2 TDO/DI input	0 0
			// ADBUS3 TMS/CS output 1 high 0
			// ADBUS4 GPIOL0 output 1 low 0
			// ADBUS5 GPIOL1 output 1 low 0
			// ADBUS6 GPIOL2 output 1 low 0
			// ADBUS7 GPIOL3 output 1 low 0
			byOutputBuffer[dwNumBytesToSend++] = 0x80;
			// Configure data bits low-byte of MPSSE port
			byOutputBuffer[dwNumBytesToSend++] = 0x00;
			// Initial state config above
			byOutputBuffer[dwNumBytesToSend++] = 0xFB;
			// Direction config above
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			// Send off the low GPIO config commands
			
			dwNumBytesToSend = 0; // Reset output buffer pointer
			// Disable internal loop-back
			byOutputBuffer[dwNumBytesToSend++] = 0x85;
			// Disable loopback
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
			// Send off the loopback command
			
			//Clear State to Test-Logic-State
			dwNumBytesToSend = 0; // Reset output buffer pointer
			byOutputBuffer[dwNumBytesToSend++] = 0x4B;
			byOutputBuffer[dwNumBytesToSend++] = 0x04;
			// Number of clock pulses = Length + 1 (5 clocks here)
			byOutputBuffer[dwNumBytesToSend++] = 0x1F;
			// Data is shifted LSB first, so the TMS pattern is 11111
			ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);
		}
	}
	else
		ftHandle = 0;
	
	jtagpara->handle = ftHandle;
	return ftStatus;
}

unsigned long  jdev_close(jtagpara_t* jtagpara)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 
	
	ftHandle = jtagpara->handle;
	ftStatus = FT_Close(ftHandle);

	if(!ftStatus)
		jtagpara->handle = 0;

	printf("[Info] Close JTAG Device[%d].\n", jtagpara->devidx);

	return ftStatus;
}

unsigned long jtag_blankinterrogation(jtagpara_t* jtagpara, fpgapara_t* support_list, fpgapara_t* detect_fpga)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus; 

	BYTE byOutputBuffer[8]; // Buffer to hold MPSSE commands and data to be sent to the FT2232H
	BYTE byInputBuffer[8]; // Buffer to hold data read from the FT2232H
	DWORD dwNumBytesToSend = 0; // Index to the output buffer
	DWORD dwNumBytesSent = 0; // Count of actual bytes sent - used with FT_Write
	DWORD dwNumBytesToRead = 0; // Number of bytes available to read in the driver's input buffer
	DWORD dwNumBytesRead = 0; // Count of actual bytes read - used with FT_Read

	ftStatus = jdev_open(jtagpara);
	
	ftHandle = jtagpara->handle;
	if(ftStatus == FT_OK && jtagpara->handle)
	{
		//Goto Shift-DR
		dwNumBytesToSend = 0; // Reset output buffer pointer
		byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
		byOutputBuffer[dwNumBytesToSend++] = 0x03;
		// Number of clock pulses = Length + 1 (5 clocks here)
		byOutputBuffer[dwNumBytesToSend++] = 0x02;
		// Data is shifted LSB first, so the TMS pattern is 0100
		ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

		//Get IDCODE
		dwNumBytesToSend = 0; // Reset output buffer pointer
		byOutputBuffer[dwNumBytesToSend++] = jtagpara->drli.bycmd;
		byOutputBuffer[dwNumBytesToSend++] = 0x03;
		// Number of clock pulses = Length + 1 (1 clocks here)
		byOutputBuffer[dwNumBytesToSend++] = 0x00;
		ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

		//Goto Test-Logic-Reset
		dwNumBytesToSend = 0; // Reset output buffer pointer
		byOutputBuffer[dwNumBytesToSend++] = jtagpara->cmd_tms;
		byOutputBuffer[dwNumBytesToSend++] = 0x03;
		// Number of clock pulses = Length + 1 (4 clocks here)
		byOutputBuffer[dwNumBytesToSend++] = 0x0F;
		// Data is shifted LSB first, so the TMS pattern is 1111	
		ftStatus = FT_Write(ftHandle, byOutputBuffer, dwNumBytesToSend, &dwNumBytesSent);

		do
		{
			ftStatus = FT_GetQueueStatus(ftHandle, &dwNumBytesToRead);
			// Get the number of bytes in the device input buffer
		} while ((dwNumBytesToRead == 0) && (ftStatus == FT_OK));
		//or Timeout
		ftStatus = FT_Read(ftHandle, &byInputBuffer, dwNumBytesToRead, &dwNumBytesRead);
		//Read out the data from input buffer

		if(dwNumBytesRead == 4) //4byte = 32bit
		{
			unsigned int i;
			unsigned int fetch;

			printf("[Action] Blank Interrogation from Device[%d]:\n", jtagpara->devidx);
			printf("IDCODE: 0x");
			for(i=0 ; i<dwNumBytesRead; i++)
				printf("%02X", *(byInputBuffer+(dwNumBytesRead-1)-i));
			printf("\n");

			printf("Revision: 0x%01X\n", *(byInputBuffer+3)>>4);
			printf("Familiy Code: 0x%02X\n", (((*(byInputBuffer+3)&0x0F)<<3)|(*(byInputBuffer+2))>>5));
			fetch = (unsigned int)(*(byInputBuffer+2));
			fetch = ((fetch&0x1F)<<4)|((*(byInputBuffer+1))>>4);
			printf("Array Code: 0x%02X\n", fetch);
			printf("(Subfamiliy Code: 0x%01X, Device Identifier: 0x%01X)\n", ((*(byInputBuffer+2))>>1)&0x0F, (((*(byInputBuffer+2))<<4)&0x10|((*(byInputBuffer+1))>>4)));
			fetch = (unsigned int)(*(byInputBuffer+1));
			fetch = ((fetch&0xF)<<7)|((*(byInputBuffer+0))>>1);
			printf("Company Code: 0x%02X\n", fetch);
			
			//fetch = 0;
			//for(i=0 ; i<dwNumBytesRead; i++)
			//{
			//	fetch = (fetch<<8)|(*(byInputBuffer+(dwNumBytesRead-1)-i));
			//}
			
			memcpy(&fetch, byInputBuffer, dwNumBytesRead);

			fetch &= 0x0FFFFFFF; //Only 3.5 bytes available, 
			i=0;
			while((support_list[i].name) != NULL) //using trick for first element is char* type
			{
				if((support_list[i]).idcode == fetch)
				{
					if(detect_fpga)
					{
						//*detect_fpga = &support_list[i];
						detect_fpga->idcode = support_list[i].idcode;
						detect_fpga->jcmd = support_list[i].jcmd;
						detect_fpga->maxbits = support_list[i].maxbits;
						detect_fpga->name = support_list[i].name;
					}

					printf("FPGA Device: %s\n", (support_list[i]).name);

					break;
				}
				i += 1;
			}
			
			if((support_list[i].name) == NULL)
			{
				printf("Not support type for Minispartan6+.\n");
			}
		}
		else
		{
			unsigned int i;
			printf("IDCODE: 0x");
			for(i=0 ; i<dwNumBytesRead; i++)
				printf("%02X", *(byInputBuffer+(dwNumBytesRead-1)-i));
			printf("\n");
			printf("Incorrect read %d bytes, need 4 bytes.\n", dwNumBytesRead);
		}

		ftStatus = jdev_close(jtagpara);
		ftHandle = NULL;
	}

	return ftStatus;
}

unsigned long jtag_cfgfpga(jtagpara_t* jtagpara, fpgapara_t* cur_fpga, char* fpgafile)
{
	FT_HANDLE ftHandle;
	FT_STATUS ftStatus;
	
	FILE *fbit=NULL;
	unsigned int fbitlen=0;
	unsigned char *pBitstream=NULL;

	if(cur_fpga == NULL)
	{
		printf("No Target FPGA parameters.\n");
		return 2; //FT_DEVICE_NOT_FOUND
	}

	if(fpgafile)
	{
		fbit = fopen(fpgafile, "rb");
		if(fbit)
		{
			//analysis .bit format
			//http://www.fpga-faq.com/FAQ_Pages/0026_Tell_me_about_bit_files.htm
			unsigned int i;
			unsigned int dlen=0;
			char* data=NULL;
			char ch;
			char segid;
			
			printf("[Info] Analysis Bitstream:\n");

			fseek(fbit, 0, SEEK_SET);
			
			//Header
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			printf("[Info] Bitstream Header: ");
			for(i=0; i<dlen; i++)
				printf("%02X", *(data+i)&0xFF);
			printf("\n");
			free(data);

			//Section a
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			//data[0] should equal 'a';
			printf("Part %c, ", data[0]);
			ch = data[0];
			free(data);
			segid = 'a';
			if(ch != segid)
			{
				printf("[Error] No Bitstream Part %c\n", segid);
				fclose(fbit);
				return segid;
			}
			
			//Design Name
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			printf("Design Name: ");
			printf("%s", data);
			printf("\n");
			free(data);

			//Section b
			dlen = 1;
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			//data[0] should equal 'b';
			printf("Part %c, ", data[0]);
			ch = data[0];
			free(data);
			segid = 'b';
			if(ch != segid)
			{
				printf("[Error] No Bitstream Part %c\n", segid);
				fclose(fbit);
				return segid;
			}

			//Part Name
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			printf("Part Name: ");
			printf("%s", data);
			printf("\n");
			free(data);
			
			//Section c
			dlen = 1;
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			//data[0] should equal 'c';
			printf("Part %c, ", data[0]);
			ch = data[0];
			free(data);
			segid = 'c';
			if(ch != segid)
			{
				printf("[Error] No Bitstream Part %c\n", segid);
				fclose(fbit);
				return segid;
			}

			//Date
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			printf("Date: ");
			printf("%s", data);
			printf("\n");
			free(data);

			//Section d
			dlen = 1;
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			//data[0] should equal 'd';
			printf("Part %c, ", data[0]);
			ch = data[0];
			free(data);
			segid = 'd';
			if(ch != segid)
			{
				printf("[Error] No Bitstream Part %c\n", segid);
				fclose(fbit);
				return segid;
			}

			//Time
			dlen = 0;
			for(i=0; i<2; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			printf("Time: ");
			printf("%s", data);
			printf("\n");
			free(data);

			//Section e
			dlen = 1;
			data = (char*)malloc(dlen);
			fread(data, dlen, 1, fbit);
			//data[0] should equal 'e';
			printf("Part %c, ", data[0]);
			ch = data[0];
			free(data);
			segid = 'e';
			if(ch != segid)
			{
				printf("[Error] No Bitstream Part %c\n", segid);
				fclose(fbit);
				return segid;
			}

			//Bitstream Length
			dlen = 0;
			for(i=0; i<4; i++)
			{
				ch = fgetc(fbit);
				dlen = (dlen<<8)+ch;
			}
			printf("[Info] Bitstream Length: ");
			printf("%d (bytes)", dlen);
			printf("\n");

			if(dlen)
			{
				fbitlen = dlen;
				dlen = 0; //Clear ro initial value.
				data = NULL; //Clear to initial value.

				pBitstream = (unsigned char*)malloc(fbitlen);
				
				fread(pBitstream, fbitlen, 1, fbit);
				
				printf("[Info] Load Bitstream Done.\n");
			}
			else
			{
				printf("[Error] Bitsream Length is ZERO!.\n");
				fclose(fbit);
				return 'f';
			}

			fclose(fbit);
		}
	}
	else
	{
		printf("[Error] No input available bitstream file.\n");
		return 0xFF;
	}

	ftStatus = jdev_open(jtagpara);
	ftHandle = jtagpara->handle;

	if(ftStatus == FT_OK && jtagpara->handle)
	{
		
		{
			unsigned char idbuf[4];
			unsigned int retlen=0;
			
			ftStatus = jf_force2tlr(jtagpara);
			ftStatus = jf_tlr2rti(jtagpara);
			
			printf("[Action] Get ID from IR IDCODE.\n");

			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x09); //IDCODE;
			ftStatus = jf_drin(jtagpara, cur_fpga, idbuf, 4, &retlen);

			/*
			{
				unsigned int i;
				printf("[Info] IR IDCODE: 0x");
				for(i=0; i<retlen; i++)
					printf("%02X", *(idbuf+(retlen-1)-i));
				printf("\n");
			}
			*/

			printf("[Action] Reset FPGA for Configure.\n");

			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x0D); //JSHUTDOWN;

			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x0B); //JPROGRAM;
			
			printf("[Action] Configure Data.\n");
			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x05); //CFG_IN;
			
			ftStatus = jf_drout(jtagpara, cur_fpga, pBitstream, fbitlen); //Write Bitstream
			
			printf("[Action] Start FPGA.\n");
			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x0C); //JSTART;

			printf("[Action] Configuration Done.\n");

			/*
			//Test Available
			ftStatus = jf_ircmd(jtagpara, cur_fpga, 0x09); //IDCODE;
			ftStatus = jf_drin(jtagpara, cur_fpga, idbuf, 4, &retlen);
			{
				unsigned int i;
				printf("IR IDCODE: 0x");
				for(i=0; i<retlen; i++)
					printf("%02X", *(idbuf+(retlen-1)-i));
				printf("\n");
			}
			*/
		}

		ftStatus = jdev_close(jtagpara);
		ftHandle = NULL;
	}

	if(pBitstream)
	{
		free(pBitstream);
		pBitstream = NULL;
	}

	return ftStatus;
}
